"""Schema overrides for VAST resources.

This file uses a hybrid model for resource field classifications:

- read_only_fields: **Auto-populated by the generator** from Swagger analysis
  (fields absent from create/update params). Updated on every generation run
  via update_schema_overrides() in generate_from_swagger.py.
- immutable_fields: Manually maintained - fields that cannot be changed after creation
- ephemeral_fields: Manually maintained - write-only fields never returned by API
- set_like_lists: Manually maintained - list fields where order doesn't matter
- lookup_field: Manually maintained - canonical identifier for idempotency lookups
- field_normalizers: Manually maintained - functions to normalize field values before comparison

The default_read_only fallback has been removed. All 79 resources have explicit
entries with auto-generated read_only_fields. Unknown resources get empty sets.

Note: Fields missing from list endpoints are automatically handled - the system
refetches from detail endpoint when user provides fields not present in list result.

These overrides are consulted by the module generator and at runtime for proper
idempotent behavior.
"""

from typing import Any, Dict, List, Optional, Set

from .utils.duration import normalize_duration, normalize_frames


def normalize_list_by_user_schema(api_value: Any, user_value: Any) -> Any:
    """Generic normalizer for list fields that keeps only user-provided keys.

    Args:
        api_value: List value returned by API (may have extra fields in each dict)
        user_value: List value provided by user (defines the schema)

    Returns:
        Normalized list with only user-provided keys, flattening nested 'entity' objects

    Example:
        User provides: [{"identifier": "user1", "hard_limit": 1000}]
        API returns: [{"entity": {"identifier": "user1", "vast_id": 123}, "hard_limit": 1000, "state": "OK"}]
        Returns: [{"identifier": "user1", "hard_limit": 1000}]
    """
    if api_value is None or user_value is None:
        return api_value
    if not isinstance(api_value, list):
        return api_value
    if len(user_value) == 0:
        return api_value

    user_schema = user_value[0]

    normalized = []
    for api_item in api_value:
        normalized_item = {}
        for key in user_schema.keys():
            try:
                if key in api_item:
                    value = api_item[key]
                elif "entity" in api_item and key in api_item["entity"]:
                    entity_value = api_item["entity"][key]
                    # The entity sub-object is the API's read-only view of the
                    # referenced user/group profile. Fields like identifier and
                    # identifier_type are reliably echoed, but others (e.g. email)
                    # may carry different semantics than the flat field the user
                    # sent.  When the entity value disagrees with what the user
                    # provided, the field is unverifiable through GET — treat it
                    # like an ephemeral/write-only field by adopting the user's
                    # value so both sides of the comparison stay consistent.
                    if entity_value != user_schema.get(key):
                        value = user_schema[key]
                    else:
                        value = entity_value
                else:
                    continue

                # Normalize "All" → "" transformation for fqdn fields (share_acl)
                if key == "fqdn" and value == "" and user_schema.get(key) == "All":
                    value = "All"

                if value is not None:
                    normalized_item[key] = value
            except (TypeError, KeyError):
                continue

        normalized.append(normalized_item)

    return normalized


def normalize_dict_by_user_schema(api_value: Any, user_value: Any) -> Any:
    """Generic normalizer for dict fields that keeps only user-provided keys.

    Args:
        api_value: Dict value returned by API (may have extra fields)
        user_value: Dict value provided by user (defines the schema)

    Returns:
        Normalized dict with only user-provided keys

    Example:
        User provides: {"soft_limit": 50000, "hard_limit": 100000}
        API returns: {"soft_limit": 50000, "hard_limit": 100000, "quota_system_id": 152, "grace_period": null}
        Returns: {"soft_limit": 50000, "hard_limit": 100000}
    """
    if api_value is None or user_value is None:
        return api_value
    if not isinstance(api_value, dict) or not isinstance(user_value, dict):
        return api_value

    normalized = {}
    for key in user_value.keys():
        if key in api_value and api_value[key] is not None:
            normalized[key] = api_value[key]

    return normalized


def normalize_share_acl(api_value: Any, user_value: Any) -> Any:
    """Normalize share_acl field (wrapper for nested acl list).

    Args:
        api_value: share_acl dict from API with nested 'acl' list
        user_value: share_acl dict from user with nested 'acl' list

    Returns:
        Normalized share_acl with only user-provided keys in acl entries
    """
    if not user_value or "acl" not in user_value:
        return api_value

    # Normalize the nested 'acl' list using generic list normalizer
    if "acl" in api_value:
        normalized_acl = normalize_list_by_user_schema(api_value["acl"], user_value["acl"])
        return {**api_value, "acl": normalized_acl}

    return api_value


def normalize_id_ref_list(value: Any, _user_value: Any) -> Optional[List]:
    """Flatten ID-reference list fields to a plain list of ids.

    Args:
        value: list of {"id": X, ...} dicts from API, or list of bare ids from user
        _user_value: unused (kept for normalizer signature compatibility)

    Returns:
        list - dicts collapsed to their "id", non-dict items pass through unchanged.
        Falsy input (None, []) is returned as-is.
    """
    if not value:
        return value
    return [item["id"] if isinstance(item, dict) else item for item in value]


# Resource-specific overrides
OVERRIDES: Dict[str, Dict[str, Any]] = {
    "views": {
        "read_only_fields": {
            "bulk_permission_update_progress",
            "bulk_permission_update_state",
            "cluster",
            "cluster_id",
            "created",
            "directory",
            "guid",
            "has_bucket_logging_destination",
            "has_bucket_logging_sources",
            "id",
            "ignore_oos",
            "internal",
            "is_remote",
            "logical_capacity",
            "nqn",
            "physical_capacity",
            "policy",
            "sync",
            "sync_time",
            "tenant_name",
            "title",
            "url",
        },
        "immutable_fields": {"path", "tenant_id"},
        "ephemeral_fields": {"create_dir"},
        "set_like_lists": {"protocols", "abac_tags", "abe_protocols"},
        "lookup_field": "path",
        "field_normalizers": {
            "share_acl": normalize_share_acl,  # Generic normalizer handles 'All' → '' and API-added fields
        },
    },
    "users": {
        "read_only_fields": {
            "access_keys",
            "group_count",
            "groups",
            "guid",
            "id",
            "is_temporary_password",
            "leading_group_gid",
            "leading_group_name",
            "local_provider",
            "password_is_set",
            "primary_group_sid",
            "provider_name",
            "s3_policies",
            "sid",
            "sids",
            "title",
            "url",
            "vid",
        },
        "immutable_fields": {
            "name",
            "local_provider_id",
        },  # Username cannot be changed, local_provider_id is write-once at creation
        "ephemeral_fields": {
            "password",  # Never returned by API; only sent on create (excluded from updates for idempotency).
        },
        "set_like_lists": {"gids"},
        "unique_constraints": {"name", "local_provider_id"},  # Users are uniquely identified by (name, local_provider_id)
        "lookup_field": "name",
    },
    "clusters": {
        "read_only_fields": {
            "active_sessions_count",
            "allow_encryption",
            "auxiliary_space_in_use",
            "auxiliary_space_in_use_tb",
            "available_logical_capacity",
            "available_physical_capacity",
            "available_upgrade_version",
            "bw",
            "bw_mb",
            "created",
            "current_gen_enabled",
            "deployment_time",
            "drive_pci_port_type",
            "drr",
            "drr_text",
            "enable_s3",
            "encryption_status",
            "encryption_transition_state",
            "estore_capacity_in_use_bytes",
            "estore_capacity_in_use_tb",
            "expansion_phase",
            "expansion_phase_description",
            "expansion_state",
            "free_logical_space",
            "free_logical_space_tb",
            "free_physical_space",
            "free_physical_space_tb",
            "free_physical_space_wo_overhead",
            "free_physical_space_wo_overhead_tb",
            "free_usable_capacity",
            "free_usable_capacity_tb",
            "guid",
            "id",
            "iops",
            "ip",
            "is_large_subnet",
            "is_wb_raid_enabled",
            "latency",
            "latency_ms",
            "leader_cnode",
            "leader_state",
            "leader_upgrade_state",
            "logical_auxiliary_space_in_use",
            "logical_auxiliary_space_in_use_tb",
            "logical_capacity",
            "logical_drr_percent",
            "logical_inodes_in_use_num",
            "logical_space",
            "logical_space_in_use",
            "logical_space_in_use_percent",
            "logical_space_in_use_tb",
            "logical_space_tb",
            "max_handles_count",
            "max_performance",
            "max_performance_metrics",
            "md_iops",
            "md_usage_health",
            "memory_raid_rebuild_progress",
            "memory_raid_state",
            "mgmt_cnode",
            "mgmt_inner_vip",
            "mgmt_inner_vip_cnode",
            "mgmt_vip",
            "micro_estore_shards",
            "mio_raid_state",
            "ndb_bandwidth",
            "ndb_bandwidth_read",
            "ndb_bandwidth_write",
            "ndb_number_of_running_queries",
            "ndb_rows_scanned_per_second",
            "nvram_raid_rebuild_progress",
            "nvram_raid_rebuild_progress_fraction",
            "nvram_raid_state",
            "online_start_time",
            "perf_check",
            "physical_capacity",
            "physical_drr_percent",
            "physical_space",
            "physical_space_in_use",
            "physical_space_in_use_percent",
            "physical_space_in_use_tb",
            "physical_space_in_use_wo_overhead",
            "physical_space_tb",
            "physical_space_wo_overhead",
            "provides_blocked",
            "quotas_allocated_capacity",
            "quotas_used_capacity",
            "quotas_used_percent",
            "raid_drives_can_fail",
            "raid_rebuild_progress",
            "rd_bw",
            "rd_bw_mb",
            "rd_iops",
            "rd_latency",
            "rd_latency_ms",
            "rd_md_iops",
            "read_bw",
            "read_iops",
            "remaining_stripes_health",
            "replication_bw_mb",
            "replication_iops",
            "replication_latency_ms",
            "replication_rd_bw_mb",
            "replication_rd_iops",
            "replication_rd_latency_ms",
            "replication_wr_bw_mb",
            "replication_wr_iops",
            "replication_wr_latency_ms",
            "rewrite_phase",
            "rewrite_progress",
            "rewrite_status",
            "rewrite_type",
            "rio_nvram_state",
            "rio_raid_rebuild_progress",
            "rio_raid_rebuild_progress_fraction",
            "s3_new_version",
            "ssd_capacity",
            "ssd_raid_rebuild_progress",
            "ssd_raid_state",
            "ssh_user",
            "state",
            "sw_version",
            "system_name",
            "system_settings",
            "title",
            "triplication_enabled",
            "turbo_boost_flag",
            "upgrade_phase",
            "upgrade_progress",
            "upgrade_state",
            "uptime",
            "url",
            "usable_auxiliary_space_in_use",
            "usable_capacity",
            "usable_capacity_bytes",
            "usable_capacity_tb",
            "usable_logical_capacity",
            "usable_physical_capacity",
            "usable_ssd_capacity",
            "used_handles_count",
            "used_handles_percent",
            "vast_audit_log_state",
            "wr_bw",
            "wr_bw_mb",
            "wr_iops",
            "wr_latency",
            "wr_latency_ms",
            "wr_md_iops",
            "write_bw",
            "write_iops",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "viewpolicies": {
        "read_only_fields": {
            "change",
            "cluster",
            "count_views",
            "created",
            "data_create_delete",
            "data_modify",
            "data_read",
            "enable_listing_of_snapshot_dir",
            "enable_snapshot_lookup",
            "full",
            "guid",
            "id",
            "internal",
            "log_deleted",
            "log_full_path",
            "log_hostname",
            "log_username",
            "pretty_atime_frequency",
            "pretty_auth_source",
            "read",
            "remote_mapping",
            "s3_bucket_listing",
            "s3_bucket_read",
            "s3_bucket_read_acp",
            "s3_bucket_write",
            "s3_bucket_write_acp",
            "s3_object_full_control",
            "s3_object_read",
            "s3_object_read_acp",
            "s3_object_write",
            "s3_object_write_acp",
            "smb_directory_mode_padded",
            "smb_file_mode_padded",
            "sync",
            "sync_time",
            "tenant_name",
            "title",
            "url",
            "views_count",
        },
        "immutable_fields": {"tenant_id"},
        "set_like_lists": {"protocols_audit", "trash_access"},
        "lookup_field": "name",
        "field_normalizers": {
            "atime_frequency": normalize_duration,
        },
    },
    "tenants": {
        "read_only_fields": {
            "ad_title",
            "client_ip_ranges_summary",
            "created",
            "data_engine_enabled",
            "dir",
            "encryption_group_id",
            "encryption_group_state",
            "encryption_status",
            "encryption_transition_state",
            "guid",
            "id",
            "krb_provider_title",
            "ldap_title",
            "local_provider",
            "local_provider_title",
            "logical_capacity",
            "nis_title",
            "oidc_provider_title",
            "physical_capacity",
            "quotas_count",
            "smb_allowed",
            "sync",
            "sync_time",
            "title",
            "url",
            "views_count",
            "vippool_names",
            "vippools",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "quotas": {
        "read_only_fields": {
            "cluster",
            "cluster_id",
            "effective_quota_capacity_tb",
            "guid",
            "id",
            "internal",
            "last_user_quotas_update",
            "num_blocked_users",
            "num_exceeded_users",
            "percent_capacity",
            "percent_inodes",
            "pretty_grace_period",
            "pretty_grace_period_expiration",
            "pretty_state",
            "state",
            "sync_state",
            "system_id",
            "tenant_name",
            "time_to_block",
            "title",
            "url",
            "used_capacity",
            "used_capacity_tb",
            "used_effective_capacity",
            "used_effective_capacity_tb",
            "used_inodes",
            "used_limited_capacity",
        },
        "immutable_fields": {"path"},
        "set_like_lists": set(),
        "lookup_field": "path",
        "field_normalizers": {
            "user_quotas": normalize_list_by_user_schema,
            "group_quotas": normalize_list_by_user_schema,
            "default_user_quota": normalize_dict_by_user_schema,
            "default_group_quota": normalize_dict_by_user_schema,
        },
    },
    "vippools": {
        "read_only_fields": {
            "active_cnode_ids",
            "active_connections",
            "active_interfaces",
            "bgp_config_guid",
            "bgp_config_name",
            "cluster",
            "cnodes",
            "created",
            "guid",
            "id",
            "ranges_summary",
            "state",
            "sync",
            "sync_time",
            "tenant_name",
            "title",
            "url",
        },
        "immutable_fields": {"role"},
        "set_like_lists": {"cnode_ids", "vlan_ids"},
        "lookup_field": "name",
    },
    "protectionpolicies": {
        "read_only_fields": {
            "created",
            "guid",
            "handle",
            "id",
            "internal",
            "is_local",
            "is_on_schedule",
            "native_replication_remote_target",
            "pretty_schedules",
            "protected_paths_count",
            "remote_tenant",
            "replication_target",
            "schedule_miss",
            "state",
            "streams_count",
            "sync_interval",
            "target_guid",
            "target_name",
            "tenant",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
        "field_normalizers": {
            "frames": normalize_frames,
        },
    },
    "protectedpaths": {
        "read_only_fields": {
            "aggr_phys_estimation",
            "bucket_name",
            "bw",
            "created",
            "estimated_read_only_time",
            "eta",
            "failback_allowed",
            "failure_reason",
            "guid",
            "health",
            "id",
            "inode_count",
            "internal",
            "is_gn_enabled",
            "is_local",
            "last_restore_point_creation_time",
            "last_restore_point_time",
            "last_run_state",
            "last_snapshot_creation_time",
            "last_uploading_restore_point_logical_size",
            "last_uploading_restore_point_physical_size",
            "last_uploading_restore_point_progress",
            "last_uploading_restore_point_state",
            "logical_size",
            "members_info",
            "peer_cluster_name",
            "peer_connection_state",
            "physical_size",
            "progress",
            "protection_policy_name",
            "remote_target_path",
            "remote_tenant_name",
            "replication_policy",
            "replication_stream_roles",
            "replication_streams",
            "replication_target_name",
            "restore_progress",
            "restore_task",
            "role",
            "role_change_eta_sec",
            "role_change_progress_promil",
            "state_description",
            "tenant_name",
            "url",
        },
        "immutable_fields": {"protection_policy_id", "source_dir", "target_exported_dir"},
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "snapshots": {
        "read_only_fields": {
            "aggr_phys_estimation",
            "cluster",
            "created",
            "data_create_time",
            "eta_sec",
            "guid",
            "id",
            "logical_capacity",
            "physical_capacity",
            "policy",
            "protection_policy",
            "protection_policy_id",
            "state",
            "subsystem_related",
            "tenant_name",
            "title",
            "type",
            "unique_phys_estimation",
            "url",
        },
        "immutable_fields": {"path"},
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "s3policies": {
        "read_only_fields": {
            "groups",
            "guid",
            "id",
            "is_replicated",
            "tenant_name",
            "title",
            "url",
            "users",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "activedirectory": {
        "read_only_fields": {
            "created",
            "guid",
            "id",
            "last_ma_pwd_renewal_status",
            "ldap",
            "ldap_id",
            "ldap_urls",
            "ma_pwd_change_frequency",
            "ma_pwd_update_time",
            "name",
            "preferred_dc_list",
            "state",
            "tenant_id",
            "title",
            "url",
        },
        "immutable_fields": {
            # LDAP-delegated fields (needed for create, stored in linked LDAP config, can't update)
            "binddn",
            "bindpw",
            "method",
            "port",
            "use_tls",
            "use_ldaps",
            "use_auto_discovery",
            "searchbase",
            "group_searchbase",
            "urls",
        },
        "set_like_lists": set(),
        "ephemeral_fields": {
            "use_posix",
            "admin_username",  # Credentials never returned by API
            "admin_passwd",  # Credentials never returned by API
            "bindpw",  # LDAP bind password never returned (also in immutable)
        },
        "flatten_subresources": {"ldap"},  # API nests LDAP-delegated fields; lift to top level for diff
        "lookup_field": "machine_account_name",
    },
    "ldaps": {
        "read_only_fields": {
            "active_directory",
            "active_directory_id",
            "guid",
            "id",
            "posix_primary_provider",
            "state",
            "tenant_id",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": {"urls"},
        "ephemeral_fields": {
            "bindpw",  # LDAP bind password never returned by API
        },
        "lookup_field": "name",
    },
    "dns": {
        "read_only_fields": {
            "cnodes",
            "guid",
            "id",
            "sync",
            "sync_time",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": {"domain_suffixes", "vip_pools"},
        "lookup_field": "name",
    },
    "qospolicies": {
        "read_only_fields": {
            "created",
            "guid",
            "id",
            "io_size_bytes",
            "tenant_name",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "groups": {
        "read_only_fields": {
            "guid",
            "id",
            "local_provider",
            "provider_name",
            "s3_policies",
            "title",
            "url",
        },
        "immutable_fields": {
            "local_provider_id",
        },  # local_provider_id is write-once at creation
        "set_like_lists": set(),
        "unique_constraints": {"gid", "local_provider_id"},  # Groups are uniquely identified by (gid, local_provider_id)
        "lookup_field": "name",
    },
    "cnodes": {
        "read_only_fields": {
            "bios_version",
            "bmc_fw_version",
            "bmc_state",
            "bmc_state_reason",
            "box_vendor",
            "build",
            "cbox",
            "cbox_id",
            "cluster",
            "cpld",
            "created",
            "data_rdma_port",
            "data_tcp_port",
            "display_name",
            "display_state",
            "enabled_ssd_count",
            "guid",
            "host_label",
            "host_opensm_master",
            "hostname",
            "id",
            "ip1",
            "ip2",
            "ipmi_ip",
            "ipv6",
            "is_leader",
            "is_mgmt",
            "is_vms",
            "led_status",
            "mgmt_ip",
            "name",
            "new_name",
            "opensm_state",
            "os_version",
            "platform_generation",
            "platform_rdma_port",
            "platform_tcp_port",
            "platform_type",
            "position",
            "psnt",
            "rpm",
            "sn",
            "ssd_count",
            "state",
            "sync",
            "sync_time",
            "title",
            "tpm_boot_dev_encryption_status",
            "turbo_boost",
            "url",
            "vlan",
            "vms_preferred",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "roles": {
        "module_name": "administrator_role",
        "read_only_fields": {
            "created",
            "guid",
            "id",
            "is_admin",
            "is_default",
            "is_system",
            "managers",
            "tenant",
            "tenant_names",
            "url",
        },
        "immutable_fields": {"tenant_id"},
        "set_like_lists": {"permissions", "permissions_list", "tenants", "tenant_ids", "ldap_groups"},
        "renamed_on_response": {
            "permissions_list": "permissions",
            "tenant_ids": "tenants",
        },
        "lookup_field": "name",
    },
    "certificates": {
        "read_only_fields": {
            "cn",
            "created",
            "expiry",
            "fingerprint",
            "guid",
            "id",
            "issuer",
            "state",
            "url",
            "valid_from",
            "valid_to",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "vtasks": {
        "read_only_fields": {
            "created",
            "end_time",
            "execution_time",
            "guid",
            "id",
            "info",
            "messages",
            "name",
            "start_time",
            "timeout_in_seconds",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "alarms": {
        "read_only_fields": {
            "alarm_message",
            "cluster",
            "event",
            "event_definition",
            "event_name",
            "event_type",
            "id",
            "last_updated",
            "metadata",
            "object_guid",
            "object_id",
            "object_name",
            "object_type",
            "rel_obj_class",
            "rel_obj_id",
            "severity",
            "timestamp",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "apitokens": {
        "read_only_fields": {
            "created",
            "id",
            "last_used",
            "revocation_time",
            "revoked",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "bgpconfigs": {
        "read_only_fields": set(),
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "bigcatalogconfig": {
        "read_only_fields": {
            "clone_type",
            "created",
            "guid",
            "handle",
            "id",
            "indestructible",
            "internal",
            "is_local",
            "is_on_schedule",
            "name",
            "native_replication_remote_target",
            "prefix",
            "pretty_schedules",
            "remote_tenant",
            "replication_target",
            "schedule_miss",
            "state",
            "sync_interval",
            "target_guid",
            "target_name",
            "target_object_id",
            "tenant",
            "tenant_id",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "blockhosts": {
        "read_only_fields": {
            "id",
            "mapped_volume_count",
            "mapped_volumes_preview",
            "tenant_name",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "callhomeconfigs": {
        "read_only_fields": {
            "callhome_upload_destination",
            "cloud_registered",
            "id",
            "ssl_certificate",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "carriers": {
        "read_only_fields": {
            "carrier_index",
            "carrier_type",
            "cluster",
            "cluster_id",
            "dbox",
            "dbox_id",
            "display_name",
            "fw_version",
            "guid",
            "hw_version",
            "id",
            "insertion_time",
            "led_status",
            "model",
            "name",
            "nvrams",
            "position",
            "shelf",
            "sn",
            "ssds",
            "state",
            "sw_version",
            "title",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "cboxes": {
        "read_only_fields": {
            "cluster",
            "cluster_id",
            "guid",
            "id",
            "index_in_rack",
            "name",
            "rack_id",
            "rack_name",
            "state",
            "subsystem",
            "title",
            "uid",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "cnodegroups": {
        "read_only_fields": {
            "cnodes",
            "guid",
            "id",
            "state",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "config": {
        "read_only_fields": {
            "is_modified",
            "key",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "dboxes": {
        "read_only_fields": {
            "arch_type",
            "box_vendor",
            "cluster",
            "cluster_id",
            "drive_type",
            "dtray",
            "guid",
            "hardware_type",
            "id",
            "index_in_rack",
            "is_conclude_possible",
            "is_migrate_source",
            "is_migrate_target",
            "is_replace_possible",
            "rack_id",
            "rack_name",
            "state",
            "subsystem",
            "sync",
            "sync_time",
            "title",
            "uid",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "dnodes": {
        "read_only_fields": {
            "arch_type",
            "bios_version",
            "bmc_fw_version",
            "bmc_state",
            "bmc_state_reason",
            "box_rdma_port",
            "build",
            "cluster",
            "cluster_id",
            "cpld",
            "data_rdma_port",
            "data_tcp_port",
            "dbox",
            "dbox_id",
            "display_name",
            "dtray",
            "ebox",
            "ebox_id",
            "guid",
            "host_label",
            "hostname",
            "id",
            "ip",
            "ip1",
            "ip2",
            "ipmi_ip",
            "ipv6",
            "is_primary",
            "led_status",
            "mgmt_ip",
            "name",
            "new_name",
            "os_version",
            "platform_rdma_port",
            "platform_tcp_port",
            "position",
            "rpm",
            "sn",
            "state",
            "sync",
            "sync_time",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "dtrays": {
        "read_only_fields": {
            "bmc_fw_version",
            "bmc_ip",
            "bmc_state",
            "bmc_state_reason",
            "cluster",
            "cpld_version",
            "dbox",
            "dbox_id",
            "dnodes",
            "guid",
            "id",
            "led_status",
            "mcu_state",
            "mcu_version",
            "name",
            "pcie_switch_firmware_version",
            "pcie_switch_mfg_version",
            "position",
            "serial_number",
            "state",
            "sync",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "eboxes": {
        "read_only_fields": {
            "arch_type",
            "box_vendor",
            "cluster",
            "cluster_id",
            "description",
            "drive_type",
            "dtray",
            "guid",
            "id",
            "index_in_rack",
            "is_conclude_possible",
            "is_replace_possible",
            "led_status",
            "name",
            "rack_id",
            "rack_name",
            "sn",
            "state",
            "subsystem",
            "sync",
            "sync_time",
            "title",
            "uid",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "encryptedpaths": {
        "read_only_fields": {
            "encryption_group",
            "id",
            "tenant_name",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "path",
    },
    "encryptiongroups": {
        "read_only_fields": {
            "crn",
            "guid",
            "id",
            "state",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "eventdefinitionconfigs": {
        "read_only_fields": {
            "id",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "eventdefinitions": {
        "read_only_fields": {
            "action_definitions",
            "alarm_definitions",
            "event_message",
            "event_type",
            "id",
            "metadata",
            "name",
            "object_type",
            "property",
            "user_modified",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "events": {
        "read_only_fields": {
            "cluster",
            "event_definition",
            "event_name",
            "event_origin",
            "guid",
            "id",
            "metadata",
            "object_guid",
            "object_name",
            "severity",
            "timestamp",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "object_type",
    },
    "folders": {
        "read_only_fields": set(),
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "globalsnapstreams": {
        "read_only_fields": {
            "bw",
            "direction",
            "eta",
            "external_state",
            "guid",
            "health",
            "id",
            "loanee_tenant",
            "restore_task",
            "source_cluster",
            "source_path",
            "source_snapshot",
            "state",
            "sync_progress",
            "target_cluster",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "iamroles": {
        "read_only_fields": {
            "guid",
            "id",
            "tenant",
            "vid",
        },
        "immutable_fields": {"name", "tenant_id"},
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "indestructibility": {
        "read_only_fields": {
            "guid",
            "id",
            "is_locked",
            "name",
            "passwd_delay_eta",
            "title",
            "token",
            "token_time",
            "unlock_system_time",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "injections": {
        "read_only_fields": {
            "values",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "kafkabrokers": {
        "read_only_fields": {
            "id",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "kerberos": {
        "read_only_fields": {
            "guid",
            "id",
            "state",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "realm",
    },
    "licenses": {
        "read_only_fields": {
            "accelerated_cpu_cores",
            "capacity",
            "cpu_cores",
            "expiration_date",
            "guid",
            "id",
            "name",
            "period",
            "start_date",
            "state",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "localproviders": {
        "read_only_fields": {
            "assigned_tenants_preview",
            "id",
        },
        "immutable_fields": set(),
        "set_like_lists": {"managed_by"},
        "lookup_field": "name",
    },
    "managedapplications": {
        "read_only_fields": {
            "guid",
            "id",
            "state",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "managers": {
        "read_only_fields": {
            "failed_logins",
            "full_name",
            "guid",
            "id",
            "is_active",
            "is_default",
            "last_login",
            "object_permissions",
            "password_expiration",
            "password_retype",
            "tenant",
        },
        "immutable_fields": set(),
        "ephemeral_fields": {
            "password",  # Never returned by API; only sent on create
        },
        "set_like_lists": {"roles"},
        "field_normalizers": {
            "roles": normalize_id_ref_list,
        },
        "lookup_field": "username",
    },
    "monitors": {
        "read_only_fields": {
            "exclude_patterns",
            "id",
            "limit",
            "metrics_exposure",
            "monitor_type",
            "query_aggregation",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "nativereplicationremotetargets": {
        "read_only_fields": {
            "address_count",
            "created",
            "guid",
            "health",
            "is_local",
            "last_heart_beat",
            "peer_name",
            "pool",
            "pool_name",
            "remote_version",
            "remote_vip_range",
            "secret",
            "space_left",
            "state",
            "state_description",
            "status",
            "sync_state",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "nicports": {
        "read_only_fields": {
            "address",
            "cluster",
            "cluster_id",
            "display_name",
            "external",
            "failure_reason",
            "fw_version",
            "guid",
            "host_id",
            "id",
            "interface",
            "model",
            "name",
            "port_membership",
            "sn",
            "state",
            "title",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "nis": {
        "read_only_fields": {
            "guid",
            "id",
            "posix_primary_provider",
            "state",
            "tenant_id",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "nvrams": {
        "read_only_fields": {
            "arch_type",
            "attached_dnode_names",
            "carrier",
            "carrier_hw_version",
            "carrier_serial",
            "carrier_sw_version",
            "cluster",
            "cluster_id",
            "dbox",
            "dbox_id",
            "display_name",
            "dnode1_attached",
            "dnode2_attached",
            "fail_reason",
            "fw_version",
            "guid",
            "id",
            "insertion_time",
            "is_remote",
            "led_status",
            "model",
            "name",
            "phase_out",
            "shelf",
            "size",
            "slot",
            "sn",
            "space_in_use",
            "state",
            "title",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "oidcs": {
        "read_only_fields": {
            "assigned_tenants_preview",
            "guid",
            "id",
            "last_keys_refresh_time",
            "state",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "projections": {
        "read_only_fields": {
            "num_rows",
            "properties",
            "size",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "racks": {
        "read_only_fields": {
            "available_capacity",
            "cnode_ip_pool",
            "cnode_ipmi_pool",
            "dnode_ip_pool",
            "dnode_ipmi_pool",
            "guid",
            "id",
            "is_bgp_enabled",
            "total_capacity",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "realms": {
        "read_only_fields": {
            "guid",
            "id",
            "tenant",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "replicationpolicies": {
        "read_only_fields": {
            "guid",
            "id",
            "replication_target_name",
            "vip_pool",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "replicationstreams": {
        "read_only_fields": {
            "bw",
            "capabilities",
            "guid",
            "id",
            "internal",
            "priority_number",
            "protected_path_guid",
            "protection_policy",
            "remote_target_id",
            "remote_target_name",
            "remote_tenant_name",
            "replication_group_id",
            "replication_policy",
            "role",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "replicationtargets": {
        "read_only_fields": {
            "created",
            "decoded_access_key",
            "guid",
            "id",
            "state",
            "state_description",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "s3keys": {
        "read_only_fields": set(),
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "s3lifecyclerules": {
        "read_only_fields": {
            "guid",
            "id",
            "title",
            "url",
            "view_path",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "schemas": {
        "read_only_fields": {
            "properties",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "snapshotpolicies": {
        "read_only_fields": {
            "cluster",
            "guid",
            "humanize_schedule",
            "id",
            "last_operation_state",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "path",
    },
    "ssds": {
        "read_only_fields": {
            "arch_type",
            "attached_dnode_names",
            "carrier",
            "carrier_hw_version",
            "carrier_serial",
            "carrier_sw_version",
            "cluster",
            "cluster_id",
            "dbox",
            "dbox_id",
            "display_name",
            "dnode1_attached",
            "dnode2_attached",
            "fail_reason",
            "fw_version",
            "guid",
            "id",
            "index_in_carrier",
            "insertion_time",
            "led_status",
            "model",
            "name",
            "shelf",
            "size",
            "slot",
            "sn",
            "space_in_use",
            "state",
            "title",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "subnetmanager": {
        "read_only_fields": {
            "failure_reason",
            "guid",
            "id",
            "name",
            "state",
            "title",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "supportbundles": {
        "read_only_fields": {
            "bundle_file",
            "bundle_size",
            "bundle_url",
            "callhome",
            "cluster",
            "cluster_id",
            "core",
            "create_datetime",
            "created",
            "guid",
            "id",
            "management",
            "mem_traces",
            "metrics",
            "name",
            "performance",
            "platform",
            "state",
            "traces",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "path",
    },
    "supporteddrives": {
        "read_only_fields": {
            "drive_type",
            "id",
            "model_name",
            "raw_data",
            "synced",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "switches": {
        "read_only_fields": {
            "cluster",
            "cluster_id",
            "configuration_file",
            "configured",
            "display_name",
            "fw_version",
            "guid",
            "hostname",
            "id",
            "install",
            "ipv6",
            "mgmt_gateway",
            "mgmt_ip",
            "mgmt_subnet",
            "model",
            "mtu",
            "name",
            "pair_id",
            "peer_switch",
            "role",
            "sn",
            "state",
            "switch_id",
            "switch_type",
            "title",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "tables": {
        "read_only_fields": {
            "acummulative_row_insertion_count",
            "num_rows",
            "properties",
            "size",
            "sorting_done",
            "sorting_key_enabled",
            "sorting_label",
            "sorting_score",
            "write_amplification",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "topics": {
        "read_only_fields": set(),
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "userquotas": {
        "read_only_fields": {
            "entity_identifier",
            "guid",
            "id",
            "path",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "vastdb": {
        "read_only_fields": set(),
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "id",
    },
    "vms": {
        "read_only_fields": {
            "auto_logout_timeout",
            "build",
            "capacity_usable",
            "created",
            "degraded_reason",
            "disable_mgmt_ha",
            "guid",
            "id",
            "ip",
            "ip1",
            "ip2",
            "ipv6_support",
            "max_api_tokens_per_user",
            "mgmt_cnode",
            "mgmt_inner_vip_cnode",
            "mgmt_ip",
            "mgmt_vip_ipv6",
            "min_qos_supported",
            "name",
            "ssl_certificate",
            "ssl_keyfile",
            "ssl_port",
            "state",
            "sw_version",
            "tabular_support",
            "title",
            "total_active_capacity",
            "total_remaining_capacity",
            "total_usage_capacity_percentage",
            "url",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "volumes": {
        "read_only_fields": {
            "capacity",
            "created",
            "id",
            "mapped_block_host_count",
            "mapped_block_hosts_preview",
            "namespace_id",
            "nguid",
            "qos_policy",
            "snapshot_data",
            "tenant_name",
            "uuid",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
    "vpntunnels": {
        "read_only_fields": {
            "cnode_id",
            "cnode_ip",
            "created_at",
            "hostname",
            "id",
            "tunnel_end_date",
            "tunnels_ips",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "username",
    },
    "webhooks": {
        "read_only_fields": {
            "certificate_name",
            "id",
        },
        "immutable_fields": set(),
        "set_like_lists": set(),
        "lookup_field": "name",
    },
}


def get_overrides(resource: str) -> Dict[str, Any]:
    """Get overrides for a specific resource.

    All resources should have entries populated by the generator.
    The empty fallback is a safety net, not a data source.
    """
    return OVERRIDES.get(
        resource,
        {
            "read_only_fields": set(),
            "immutable_fields": set(),
            "set_like_lists": set(),
            "unique_constraints": set(),
            "lookup_field": "name",
        },
    )


def get_read_only_fields(resource: str) -> Set[str]:
    """Get read-only fields for a resource."""
    return get_overrides(resource).get("read_only_fields", set())


def get_immutable_fields(resource: str) -> Set[str]:
    """Get immutable fields for a resource."""
    return get_overrides(resource).get("immutable_fields", set())


def get_set_like_lists(resource: str) -> Set[str]:
    """Get set-like list fields for a resource."""
    return get_overrides(resource).get("set_like_lists", set())


def get_ephemeral_fields(resource: str) -> Set[str]:
    """Get ephemeral fields for a resource (credentials/secrets never returned by API)."""
    return get_overrides(resource).get("ephemeral_fields", set())


def get_lookup_field(resource: str) -> str:
    """Get lookup field for a resource."""
    return get_overrides(resource).get("lookup_field", "name")


def is_read_only(resource: str, field: str) -> bool:
    """Check if a field is read-only for a resource."""
    return field in get_read_only_fields(resource)


def is_immutable(resource: str, field: str) -> bool:
    """Check if a field is immutable for a resource."""
    return field in get_immutable_fields(resource)


def is_set_like(resource: str, field: str) -> bool:
    """Check if a field is a set-like list for a resource."""
    return field in get_set_like_lists(resource)


def is_ephemeral(resource: str, field: str) -> bool:
    """Check if a field is ephemeral (credentials/secrets) for a resource."""
    return field in get_ephemeral_fields(resource)


def get_unique_constraints(resource: str) -> Set[str]:
    """Get unique constraint fields for a resource."""
    return get_overrides(resource).get("unique_constraints", set())


def is_unique_constraint(resource: str, field: str) -> bool:
    """Check if a field is part of unique constraints."""
    return field in get_unique_constraints(resource)
