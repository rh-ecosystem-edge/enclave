# vastdata.vms

Ansible Collection for VAST VMS. Manage VAST views, policies, and related resources.

## Modules

- **vast_view**: Create, update, or delete VAST views.

## Requirements

- Python >= 3.9
- requests (typically already installed with ansible-core)

## Roles

### `protectedpath`

The repository includes `protectedpath` for declarative VAST protected path workflows, including replication VIP pools, native replication peers, protection policies, protected paths, multistream replication, and standby streams.

## See Also

See the root [README](../../../../README.md) for installation and quickstart.
